///
// Copyright (c) Microsoft. All rights reserved.
// See https://aka.ms/csspeech/license201809 for the full license information.
//

#import <Foundation/Foundation.h>

#define SPX_EXPORT __attribute__((visibility ("default")))

